The 'pages' package contains all the page classes.
Each page class contains the web elements and actions that can be performed on those classes.