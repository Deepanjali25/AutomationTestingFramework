package test.test;

public class loginTest {
}
// The ‘test’ package contains all the test classes.
// Each test class extends the TestBase.java class and contains the test scripts.