import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(tags = "", features = {"src/resources/feature/LoginPage.feature"}, glue = {" "})

public class CucumberRunnerTests extends AbstractTestNGCucumberTests {

}